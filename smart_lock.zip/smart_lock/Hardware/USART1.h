#ifndef __USART1_H
#define __USART1_H
#include "stm32f10x.h"                  // Device header
#include <stdio.h>

extern uint8_t Serial_TxPacket[];
extern uint8_t Serial_RxPacket[];
extern char RFID_Serial_RxPacket[8];
extern char RFID_Serial_RxPacket_clear[1];

void Serial_Init(void);
void Serial_SendByte(uint8_t Byte);
void Serial_SendArray(uint8_t *Array, uint16_t Length);
void Serial_SendString(char *String);
void Serial_SendNumber(uint32_t Number, uint8_t Length);
void Serial_Printf(char *format, ...);
uint8_t RFID_Serial_GetRxFlag(void);
uint8_t RFID_Serial_GetRxFlag_clear(void);
void Serial_SendPacket(void);
uint8_t Serial_GetRxFlag(void);
#endif
