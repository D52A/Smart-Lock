#ifndef __KEYBORD_H
#define __KEYBORD_H
#include "stm32f10x.h"                  // Device header

void Keybord_Init(void);


uint16_t Keybord_GetNum(void);
#endif
