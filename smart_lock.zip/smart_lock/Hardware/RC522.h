#ifndef __RC522_H
#define __RC522_H
void IC_test ( void );
void RC522_Handle(void);
void RC522_Init ( void );

#endif