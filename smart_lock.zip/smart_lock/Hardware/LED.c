#include "stm32f10x.h"                  // Device header


//LED:1.��ʼ�� 2.�ص� 3.����

void LED_Init(void)
{
	//GPIOA_PIN1/PIN2
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
		
		GPIO_InitTypeDef GPIO_InitStructure;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOA, &GPIO_InitStructure); 
}

void LED1_On(void)
{
		GPIO_ResetBits(GPIOA, GPIO_Pin_11);
}

void LED1_Off(void)
{
		GPIO_SetBits(GPIOA, GPIO_Pin_11);
}

void LED2_On(void)
{
		GPIO_ResetBits(GPIOA, GPIO_Pin_12);
}

void LED2_Off(void)
{
		GPIO_SetBits(GPIOA, GPIO_Pin_12);
}

void LED3_On(void)
{
		GPIO_ResetBits(GPIOA, GPIO_Pin_15);
}

void LED3_Off(void)
{
		GPIO_SetBits(GPIOA, GPIO_Pin_15);
}