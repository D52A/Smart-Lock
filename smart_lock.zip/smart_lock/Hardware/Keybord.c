#include "stm32f10x.h"                  // Device header
#include "Delay.h"

//���ϵ��� B4,B5,B6,B7,B11,B10,B9,B8
void Keybord_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure; 
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	
	GPIO_InitTypeDef GPIO_InitStructure_1; 
	GPIO_InitStructure_1.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStructure_1.GPIO_Pin=GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11;
	GPIO_InitStructure_1.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure_1);
	GPIO_SetBits(GPIOB,GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11);
}

uint16_t Keybord_GetNum(void)
{
	uint8_t KeyBord_Num = 0 ;
   //��һ�� ����
   GPIO_ResetBits(GPIOB,GPIO_Pin_11);
   GPIO_SetBits(GPIOB,GPIO_Pin_10);    
   GPIO_SetBits(GPIOB,GPIO_Pin_9);
   GPIO_SetBits(GPIOB,GPIO_Pin_8);
	if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7) == 0)
	{
	    Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7) == 0);
		Delay_ms(20);
		KeyBord_Num = 1;
	}
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6) == 0)
	{
	    Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6) == 0);
		Delay_ms(20);
		KeyBord_Num = 2;
	}
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5) == 0)
	{
	    Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5) == 0);
		Delay_ms(20);
		KeyBord_Num = 3;
	}
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4) == 0)
	{
	    Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4) == 0);
		Delay_ms(20);
		KeyBord_Num = 11;
	}
	//�ڶ��� ����
   GPIO_SetBits(GPIOB,GPIO_Pin_11);
   GPIO_ResetBits(GPIOB,GPIO_Pin_10);
   GPIO_SetBits(GPIOB,GPIO_Pin_9);
   GPIO_SetBits(GPIOB,GPIO_Pin_8);
	
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7) == 0)
	{
	    Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7) == 0);
		Delay_ms(20);
		KeyBord_Num = 4;
	}
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6) == 0)
	{
	    Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6) == 0);
		Delay_ms(20);
		KeyBord_Num = 5;
	}
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5) == 0)
	{
	    Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5) == 0);
		Delay_ms(20);
		KeyBord_Num = 6;
	}
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4) == 0)
	{
	    Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4) == 0);
		Delay_ms(20);
		KeyBord_Num = 12;
	}
	//������ ����
   GPIO_SetBits(GPIOB,GPIO_Pin_11);
   GPIO_SetBits(GPIOB,GPIO_Pin_10);
   GPIO_ResetBits(GPIOB,GPIO_Pin_9);
   GPIO_SetBits(GPIOB,GPIO_Pin_8);
	
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7) == 0)
	{
	    Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7) == 0);
		Delay_ms(20);
		KeyBord_Num = 7;
	}
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6) == 0)
	{
	    Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6) == 0);
		Delay_ms(20);
		KeyBord_Num = 8;
	}
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5) == 0)
	{
	    Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5) == 0);
		Delay_ms(20);
		KeyBord_Num = 9;
	}
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4) == 0)
	{
	    Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4) == 0);
		Delay_ms(20);
		KeyBord_Num = 13;
	}
	//������ ����
	GPIO_SetBits(GPIOB,GPIO_Pin_11);
   GPIO_SetBits(GPIOB,GPIO_Pin_10);
   GPIO_SetBits(GPIOB,GPIO_Pin_9);
   GPIO_ResetBits(GPIOB,GPIO_Pin_8);
	
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7) == 0)
	{
	    Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7) == 0);
		Delay_ms(20);
		KeyBord_Num = 14;
	}
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6) == 0)
	{
	    Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6) == 0);
		Delay_ms(20);
		KeyBord_Num = 10;
	}
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5) == 0)
	{
	    Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5) == 0);
		Delay_ms(20);
		KeyBord_Num = 15;
	}
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4) == 0)
	{
	    Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4) == 0);
		Delay_ms(20);
		KeyBord_Num = 16;
	}
	return KeyBord_Num;
}
	