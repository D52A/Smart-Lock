#include "stm32f10x.h"                  // Device header
#include "oled.h"
#include "Delay.h"
#include "Keybord.h"
#include "Timer.h"
#include "Servo.h"
#include "PWM.h"
#include "string.h"
#include "USART1.h"
#include "RC522.h"
#include "stmflash.h"
#include "Buzzer.h"

#define SYS_SAVEADDR 0x0800f000   //

uint16_t ADValue;
uint16_t PassWord;
uint8_t pwd[6];// ����λ��
uint8_t j = 0;
uint16_t Keybord_Num;
uint8_t OK[6] = {9, 8, 7, 6, 5, 4}; // ��ʼ����
uint8_t Password_OK_Flag;
uint8_t ID1, ID2, ID3, ID4, ID5;
uint8_t Buzzer_Err;
extern uint8_t Card_OK;
extern uint8_t cnt;    //����
extern uint8_t Card_Acquisition;

extern unsigned char Card_ID1[8];
extern unsigned char Card_ID2[8];
extern unsigned char Card_ID3[8];
extern unsigned char Card_ID4[8];
extern unsigned char Card_ID5[8];

void Starting(void);
void Judgment_Button(void);
void Bluetooth_Password(void);
void Add_Card_ID(void);
void Delete_Card_ID(void);

unsigned char Card_ID_TEST[8] = {1, 2, 3, 4, 5, 6, 7, 8};
unsigned char Card_ID_READ[8] = {0};
int main(void)
{
    LED_Init();
    OLED_Init();
    OLED_Clear();
    Keybord_Init();
    Servo_Init();
    Timer_Init();
    Serial_Init();
    RC522_Init();
    Starting();
    Servo_SetAngle(20);
    Buzzer_Init();
    AD_Init();

//	STMFLASH_Read(SYS_SAVEADDR,(uint16_t*)&OK,3);  //�����������,  ע�͵���仰�ع��ʼ����
    while(1)
    {
        ADValue = AD_GetValue();  //����ʽ���⴫���� �����˿������𣬷�֮������
        if(ADValue > 0)
        {
            LED3_Off();
        }

        Delay_ms(100);




        // ����
        Judgment_Button();
        if(Keybord_Num != 0)
        {
            cnt = 0;
        }
        if(cnt > 5)
        {
            OLED_Clear();
            Starting();
            memset(pwd, 0, sizeof(pwd));
            j = 0;
            cnt = 0;
            Servo_SetAngle(20);
            Password_OK_Flag = 0;
        }
        //������
        if(Buzzer_Err == 3)
        {
            Buzzer_ON();
            Delay_ms(200);
            Buzzer_OFF();
            Delay_ms(200);

            Buzzer_ON();
            Delay_ms(200);
            Buzzer_OFF();
            Delay_ms(200);

            Buzzer_ON();
            Delay_ms(200);
            Buzzer_OFF();
            Delay_ms(200);

            Buzzer_Err = 0;

        }
        // ����ͨ��
        Bluetooth_Password();
        //��ƵRC522
        RC522_Handle();
        if(Card_OK == 0)
        {
            Card_OK = 2;
            OLED_Clear();
            OLED_ShowCHinese(0, 0, 0);
            OLED_ShowCHinese(20, 0, 1);
            OLED_ShowCHinese(40, 0, 2);
            OLED_ShowCHinese(60, 0, 3);
            OLED_ShowString(1, 3, "IDCard ERR", 12);

            Buzzer_ON();
            Delay_ms(200);
            Buzzer_OFF();
            Delay_ms(200);

            for(int i = 0; i < 3; i++)
            {
                Delay_ms(500);
                LED1_Off();
                Delay_ms(500);
                LED1_On();
            }
            Delay_ms(500);

            LED1_On();
            OLED_Clear();
            Starting();
            memset(pwd, 0, sizeof(pwd));
            j = 0;
            Servo_SetAngle(20);
            cnt = 0;

        }

        if(Card_OK == 1)
        {
            Card_OK = 2;
            OLED_Clear();
            OLED_ShowCHinese(0, 0, 0);
            OLED_ShowCHinese(20, 0, 1);
            OLED_ShowCHinese(40, 0, 4);
            OLED_ShowCHinese(60, 0, 5);
            OLED_ShowString(1, 3, "IDCard OK", 12);


            Servo_SetAngle(180);
            Password_OK_Flag = 1;

            LED2_Off();
            Delay_ms(2000);
            LED2_On();
            cnt = 0;
        }



        if(Card_Acquisition == 1)
        {
            uint8_t wei;

            if(Card_ID1[0] == '0' && Card_ID1[1] == '0')
            {
                ID1 = 1;
            }
            else
                ID1 = 0;

            if(Card_ID2[0] == '0' && Card_ID2[1] == '0')
            {
                ID2 = 1;
            }
            else
                ID2 = 0;

            if(Card_ID3[0] == '0' && Card_ID3[1] == '0')
            {
                ID3 = 1;
            }
            else
                ID3 = 0;

            if(Card_ID4[0] == '0' && Card_ID4[1] == '0')
            {
                ID4 = 1;
            }
            else
                ID4 = 0;

            if(Card_ID5[0] == '0' && Card_ID5[1] == '0')
            {
                ID5 = 1;
            }
            else
                ID5 = 0;

            printf("��ǰ����Card_ID����,�ܹ��ɴ洢5��Card_ID\r\n");
            if(ID1 == 0)
            {
                printf("\r\nCard_ID1 = ");
                for(wei = 0; wei < 8; wei++)
                {
                    printf("%c", Card_ID1[wei]);
                }
                printf("\r\n");
                printf("\r\n");
            }

            if(ID2 == 0)
            {
                printf("Card_ID2 = ");
                for(wei = 0; wei < 8; wei++)
                {

                    printf("%c", Card_ID2[wei]);
                }
                printf("\r\n");
                printf("\r\n");
            }
            if(ID3 == 0)
            {
                printf("Card_ID3 = ");
                for(wei = 0; wei < 8; wei++)
                {

                    printf("%c", Card_ID3[wei]);
                }
                printf("\r\n");
                printf("\r\n");
            }
            if(ID4 == 0)
            {
                printf("Card_ID4 = ");
                for(wei = 0; wei < 8; wei++)
                {

                    printf("%c", Card_ID4[wei]);
                }
                printf("\r\n");
                printf("\r\n");
            }
            if(ID5 == 0)
            {
                printf("Card_ID5 = ");
                for(wei = 0; wei < 8; wei++)
                {

                    printf("%c", Card_ID5[wei]);
                }
                printf("\r\n");
                printf("\r\n");
            }
            printf("ʣ�����Card_IDΪ%d\r\n\r\n", ID1 + ID2 + ID3 + ID4 + ID5);

            Card_Acquisition = 0;
            printf("���û�ѡ��\r\n\r\n���ӿ��� -> a + ���к��Իس���β\r\n\r\nɾ������ -> d + ���к�\r\n\r\nȡ������ -> ��������\r\n\r\n");


        }
        // ���ӿ�Ƭ
        Add_Card_ID();
        // ɾ����Ƭ
        Delete_Card_ID();




    }


}

void Starting(void)
{
    OLED_ShowCHinese(0, 0, 0);
    OLED_ShowCHinese(20, 0, 1);
    OLED_ShowChar(36, 0, ':', 16);
    OLED_ShowNum(24, 3, 1, 1, 12);
    OLED_ShowNum(48, 3, 2, 1, 12);
    OLED_ShowNum(72, 3, 3, 1, 12);
    OLED_ShowNum(24, 5, 4, 1, 12);
    OLED_ShowNum(48, 5, 5, 1, 12);
    OLED_ShowNum(72, 5, 6, 1, 12);
    OLED_ShowNum(24, 7, 7, 1, 12);
    OLED_ShowNum(48, 7, 8, 1, 12);
    OLED_ShowNum(72, 7, 9, 1, 12);
    OLED_ShowString(96, 3, "Bck", 12);
    OLED_ShowString(96, 5, "Del", 12);
    OLED_ShowString(100, 7, "OK", 12);

}

void Judgment_Button(void)
{
    Keybord_Num = Keybord_GetNum();
    if(Keybord_Num)
    {

        if(Keybord_Num < 10)
        {

            if(j < 6)
            {
                PassWord = Keybord_Num % 10;
                pwd[j] = PassWord;
            }
            j++;

            for(int i = 0; i < 6; i++)
            {


                if(pwd[i] == 0 && Password_OK_Flag == 0)
                {
                    OLED_ShowString(48 + i * 12, 1, "_", 12);
                }
                if(pwd[i] != 0 && Password_OK_Flag == 0)
                    OLED_ShowString(48 + i * 12, 1, "*", 12);


            }
        }
        if(Keybord_Num == 13)    //ȷ������
        {

            for(int k = 0; k < 6; k++)
            {
                if(pwd[k] != OK[k])
                {
                    OLED_Clear();
                    OLED_ShowCHinese(0, 0, 0);
                    OLED_ShowCHinese(20, 0, 1);
                    OLED_ShowCHinese(40, 0, 2);
                    OLED_ShowCHinese(60, 0, 3);
                    OLED_ShowString(1, 3, "Password ERR", 12);
                    printf("�������!!\r\n");
                    for(int i = 0; i < 3; i++)
                    {
                        Delay_ms(500);
                        LED1_Off();
                        Delay_ms(500);
                        LED1_On();
                    }

                    Delay_ms(500);
                    LED1_On();

                    OLED_Clear();

                    Starting();
                    memset(pwd, 0, sizeof(pwd));
                    j = 0;
                    Servo_SetAngle(20);
                    Buzzer_Err += 1;


                    return ;
                }

            }
            OLED_Clear();
            OLED_ShowCHinese(0, 0, 0);
            OLED_ShowCHinese(20, 0, 1);
            OLED_ShowCHinese(40, 0, 4);
            OLED_ShowCHinese(60, 0, 5);
            OLED_ShowString(1, 3, "Password OK", 12);
            Servo_SetAngle(180);
            Password_OK_Flag = 1;
            LED2_Off();
            Delay_ms(2000);
            LED2_On();

        }
        if(Keybord_Num == 12)    // �����������λ
        {
            if(Password_OK_Flag == 0)
            {
                for(int n = 0; n < 6; n++)
                {
                    pwd[n] = 0;
                    OLED_ShowString(48 + n * 12, 1, "_", 12);

                }
                j = 0;
            }

        }
        if(Keybord_Num == 11)    //���һλ����λ
        {
            if(Password_OK_Flag == 0)
            {
                if(j > 0 && j < 7)
                {
                    j--;
                    pwd[j] = 0;
                }
                OLED_ShowString(48 + j * 12, 1, "_", 12);
            }
        }
        if(Keybord_Num == 10)
        {

            OLED_Clear();
            Starting();
            Servo_SetAngle(20);
            memset(pwd, 0, sizeof(pwd));
            j = 0;
            Password_OK_Flag = 0;

        }

    }

}

void Bluetooth_Password(void)
{
    if(Serial_GetRxFlag() == 1)
    {
        OK[0] = Serial_RxPacket[0];
        OK[1] = Serial_RxPacket[1];
        OK[2] = Serial_RxPacket[2];
        OK[3] = Serial_RxPacket[3];
        OK[4] = Serial_RxPacket[4];
        OK[5] = Serial_RxPacket[5];
        printf("�����޸����");

        STMFLASH_Write(SYS_SAVEADDR, (uint16_t*)&OK, sizeof(OK)); //���浽�ڲ�FLASH
    }

}

void Add_Card_ID(void)
{
    uint8_t wei;
    if(RFID_Serial_GetRxFlag() == 1)
    {
        if(ID1 == 1)
        {
            for(wei = 0; wei < 8; wei++)
            {
                Card_ID1[wei] = RFID_Serial_RxPacket[wei];

            }
            printf("Card_ID1���ӳɹ�");
            ID1 = 0;
            return;
        }
        if(ID2 == 1)
        {
            for(wei = 0; wei < 8; wei++)
            {
                Card_ID2[wei] = RFID_Serial_RxPacket[wei];

            }
            printf("Card_ID2���ӳɹ�");
            ID2 = 0;
            return;
        }
        if(ID3 == 1)
        {
            for(wei = 0; wei < 8; wei++)
            {
                Card_ID3[wei] = RFID_Serial_RxPacket[wei];

            }
            printf("Card_ID3���ӳɹ�");
            ID3 = 0;
            return;
        }
        if(ID4 == 1)
        {
            for(wei = 0; wei < 8; wei++)
            {
                Card_ID4[wei] = RFID_Serial_RxPacket[wei];

            }
            printf("Card_ID4���ӳɹ�");
            ID4 = 0;
            return;
        }
        if(ID5 == 1)
        {
            for(wei = 0; wei < 8; wei++)
            {
                Card_ID5[wei] = RFID_Serial_RxPacket[wei];

            }
            printf("Card_ID5���ӳɹ�");
            ID5 = 0;
            return;
        }
        if(ID1 == 1 && ID2 == 1 && ID3 == 1 && ID4 == 1 && ID5 == 1)
            printf("ʣ�����Card_IDΪ0,�޷�����,��ѡ��ɾ������ʹ��Card_ID");




    }


}

void Delete_Card_ID(void)
{
    if(RFID_Serial_GetRxFlag_clear() == 1)
    {
        if(RFID_Serial_RxPacket_clear[0] == '1')
        {
            memset(Card_ID1, '0', sizeof(pwd));
            printf("ɾ��Card_ID1�ɹ�");
        }
        if(RFID_Serial_RxPacket_clear[0] == '2')
        {
            memset(Card_ID2, '0', sizeof(pwd));
            printf("ɾ��Card_ID2�ɹ�");
        }
        if(RFID_Serial_RxPacket_clear[0] == '3')
        {
            memset(Card_ID3, '0', sizeof(pwd));
            printf("ɾ��Card_ID3�ɹ�");
        }
        if(RFID_Serial_RxPacket_clear[0] == '4')
        {
            memset(Card_ID4, '0', sizeof(pwd));
            printf("ɾ��Card_ID4�ɹ�");
        }
        if(RFID_Serial_RxPacket_clear[0] == '5')
        {
            memset(Card_ID5, '0', sizeof(pwd));
            printf("ɾ��Card_ID5�ɹ�");
        }

    }

}


